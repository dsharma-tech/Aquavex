//
//  ResultView.swift
//  AquaWorld
//
//  Created by Disha Sharma on 15/02/25.
//

import SwiftUI

struct ResultView: View {
    let animal: MarineAnimal
    
    var body: some View {
        VStack {
            Text("You are a...")
                .font(.title)
                .bold()
            
            Image(animal.imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 150, height: 150)
            
            Text(animal.name)
                .font(.largeTitle)
                .bold()
                .padding(.top, 8)
            
            Text(animal.description)
                .font(.body)
                .multilineTextAlignment(.center)
                .padding()
            
            Button(action: {
                // Navigate back or go to the Aquarium
            }) {
                Text("Add to My Aquarium")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
        .padding()
    }
}
