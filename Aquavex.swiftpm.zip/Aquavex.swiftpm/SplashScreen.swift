//
//  SwiftUIView.swift
//  AquaWorld
//
//  Created by Disha Sharma on 15/02/25.
//

import SwiftUI

struct SplashScreen: View {
    @State private var waveOffset: CGFloat = 0
    @State private var isActive = false

    var body: some View {
        ZStack {
            VStack {
                Spacer()
                WaveView(offset: waveOffset)
                    .frame(height: 150)
                    .onAppear {
                        withAnimation(Animation.linear(duration: 2).repeatForever(autoreverses: false)) {
                            waveOffset = UIScreen.main.bounds.width
                        }
                    }
            }
            .edgesIgnoringSafeArea(.all)

            VStack {
                Text("Aquavex")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .shadow(radius: 5)

                Text("Explore the Deep Blue!")
                    .font(.title3)
                    .foregroundColor(.white.opacity(0.8))
                    .padding(.top, 5)
            }
        }
        .background(LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.blue]), startPoint: .top, endPoint: .bottom))
        .edgesIgnoringSafeArea(.all)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    isActive = true
                }
            }
        }
        .fullScreenCover(isPresented: $isActive) {
            HomeView()
        }
    }
}

struct WaveView: View {
    var offset: CGFloat
    
    var body: some View {
        ZStack {
            ForEach(0..<2) { i in
                WaveShape()
                    .offset(x: offset - CGFloat(i) * UIScreen.main.bounds.width)
                    .foregroundColor(Color.white.opacity(0.3))
            }
        }
    }
}

struct WaveShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let waveHeight: CGFloat = 20
        let wavelength = rect.width / 2

        path.move(to: CGPoint(x: 0, y: rect.height))
        
        for x in stride(from: 0, to: rect.width + wavelength, by: 1) {
            let y = sin(x / wavelength * .pi * 2) * waveHeight + rect.height - waveHeight
            path.addLine(to: CGPoint(x: x, y: y))
        }
        
        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
        path.addLine(to: CGPoint(x: 0, y: rect.height))
        path.closeSubpath()

        return path
    }
}

struct SplashScreen_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreen()
    }
}
