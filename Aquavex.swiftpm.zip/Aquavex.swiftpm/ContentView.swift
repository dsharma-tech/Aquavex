import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            HomeView() 
                .navigationBarTitleDisplayMode(.large)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
