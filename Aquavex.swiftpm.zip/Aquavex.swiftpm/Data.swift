//
//  Data.swift
//  AquaWorld
//
//  Created by Disha Sharma on 15/02/25.
//

import Foundation
struct QuizQuestion {
    let question: String
    let options: [String]
}

let quizQuestions: [QuizQuestion] = [
    QuizQuestion(question: "What’s your favorite way to spend time?", options: [
        "Swimming fast! 🏊‍♂️",
        "Exploring deep places 🔍",
        "Relaxing in the sun ☀️",
        "Hiding & watching 👀"
    ]),
    QuizQuestion(question: "Which color do you like most?", options: [
        "Bright & colorful 🎨",
        "Deep ocean blue 🌊",
        "Green & nature-like 🍃",
        "Soft pastels 🎭"
    ]),
    QuizQuestion(question: "How do you handle problems?", options: [
        "Face them head-on! 💪",
        "Stay calm and think 🧘‍♂️",
        "Go with the flow 🌊",
        "Find a clever way out 🤔"
    ])
]
// MARK: - Marine Animal Model
struct MarineAnimal: Identifiable {
    let id = UUID()
    let name: String
    let imageName: String
    let description: String
    let scientificName: String
    let commonName: String
    let averageSize: String
    let lifeSpan: String
    let bodyShape: String
    let habitat: String
    let diet: String
    
    var isUnlocked: Bool = false
}

struct MarineCategory {
    let title: String
    let animals: [MarineAnimal]
}

let marineCategories: [MarineCategory] = [
    MarineCategory(title: "Fish", animals: [
        MarineAnimal(
                         name: "Clownfish",
                         imageName: "Clownfish",
                         description: "Clownfish are small, brightly colored fish that form symbiotic relationships with sea anemones.",
                         scientificName: "Amphiprioninae",
                         commonName: "Clownfish",
                         averageSize: "4-5 inches (10-12 cm)",
                         lifeSpan: "6-10 years",
                         bodyShape: "Oval-shaped with rounded fins",
                         habitat: "Tropical coral reefs, mainly in the Indo-Pacific region.",
                         diet: "Plankton, algae, and small crustaceans."),
            
            MarineAnimal(
                         name: "Goldfish",
                         imageName: "Goldfish",
                         description: "Goldfish are one of the most popular freshwater aquarium fish, known for their golden coloration.",
                         scientificName: "Carassius auratus",
                         commonName: "Goldfish",
                         averageSize: "6-14 inches (15-35 cm)",
                         lifeSpan: "10-15 years",
                         bodyShape: "Rounded body with flowing fins",
                         habitat: "Freshwater lakes, ponds, and slow-moving rivers.",
                         diet: "Flakes, pellets, insects, and plant matter."),
            
            MarineAnimal(
                         name: "Tuna",
                         imageName: "Tuna",
                         description: "Tuna are fast-swimming fish known for their streamlined bodies and importance in commercial fishing.",
                         scientificName: "Thunnus",
                         commonName: "Tuna",
                         averageSize: "3-10 feet (1-3 meters)",
                         lifeSpan: "10-15 years",
                         bodyShape: "Torpedo-shaped body for high-speed swimming",
                         habitat: "Open ocean in tropical and temperate waters.",
                         diet: "Small fish, squid, and crustaceans."),
            
            MarineAnimal(
                         name: "Salmon",
                         imageName: "Salmon",
                         description: "Salmon are anadromous fish, meaning they migrate from saltwater to freshwater to spawn.",
                         scientificName: "Salmo salar",
                         commonName: "Salmon",
                         averageSize: "2-5 feet (60-150 cm)",
                         lifeSpan: "3-7 years",
                         bodyShape: "Streamlined body with a forked tail",
                         habitat: "Cold ocean waters and freshwater rivers.",
                         diet: "Insects, crustaceans, and small fish."),
            
            MarineAnimal(
                         name: "Betta Fish",
                         imageName: "Betta Fish",
                         description: "Betta fish are known for their vivid colors and aggressive territorial behavior.",
                         scientificName: "Betta splendens",
                         commonName: "Betta Fish",
                         averageSize: "2.5-3 inches (6-7 cm)",
                         lifeSpan: "2-5 years",
                         bodyShape: "Slender body with large, flowing fins",
                         habitat: "Shallow freshwater ponds and rice paddies.",
                         diet: "Insects, mosquito larvae, and fish flakes."),
            
            MarineAnimal(
                         name: "Guppy",
                         imageName: "Guppy",
                         description: "Guppies are small, colorful freshwater fish that are highly adaptable to different environments.",
                         scientificName: "Poecilia reticulata",
                         commonName: "Guppy",
                         averageSize: "1-2.5 inches (2.5-6 cm)",
                         lifeSpan: "1-3 years",
                         bodyShape: "Slender body with fan-shaped tail",
                         habitat: "Freshwater streams and ponds.",
                         diet: "Algae, small invertebrates, and fish flakes."),
            
            MarineAnimal(
                         name: "Angelfish",
                         imageName: "Angelfish",
                         description: "Angelfish are beautiful freshwater fish known for their disc-shaped bodies and long fins.",
                         scientificName: "Pterophyllum",
                         commonName: "Angelfish",
                         averageSize: "6 inches (15 cm)",
                         lifeSpan: "10-15 years",
                         bodyShape: "Tall, disc-shaped body with elongated fins",
                         habitat: "Slow-moving freshwater rivers and floodplains.",
                         diet: "Small insects, crustaceans, and plant matter."),
            
            MarineAnimal(
                         name: "Pufferfish",
                         imageName: "Pufferfish",
                         description: "Pufferfish can inflate their bodies as a defense mechanism and are known for their toxicity.",
                         scientificName: "Tetraodontidae",
                         commonName: "Pufferfish",
                         averageSize: "6-24 inches (15-60 cm)",
                         lifeSpan: "5-10 years",
                         bodyShape: "Round, bloated body with small fins",
                         habitat: "Tropical and subtropical ocean waters.",
                         diet: "Mollusks, crustaceans, and algae."),
            
            MarineAnimal(
                         name: "Catfish",
                         imageName: "Catfish",
                         description: "Catfish are bottom-dwelling fish recognized by their whisker-like barbels.",
                         scientificName: "Siluriformes",
                         commonName: "Catfish",
                         averageSize: "1-8 feet (30 cm - 2.5 meters)",
                         lifeSpan: "8-20 years",
                         bodyShape: "Elongated body with whisker-like barbels",
                         habitat: "Freshwater lakes, rivers, and swamps.",
                         diet: "Algae, small fish, and insects."),
            
            MarineAnimal(
                         name: "Swordfish",
                         imageName: "Swordfish",
                         description: "Swordfish are large, fast-swimming fish with a long, sword-like bill used to slash prey.",
                         scientificName: "Xiphias gladius",
                         commonName: "Swordfish",
                         averageSize: "6-15 feet (1.8-4.5 meters)",
                         lifeSpan: "9-12 years",
                         bodyShape: "Long, streamlined body with a distinctive bill",
                         habitat: "Warm and temperate ocean waters.",
                         diet: "Squid, fish, and crustaceans.")
    ]),

    MarineCategory(title: "Sharks & Rays", animals: [
        MarineAnimal(
                name: "Great White Shark",
                imageName: "Great White Shark",
                description: "The Great White Shark is one of the ocean's top predators, known for its size and powerful bite.",
                scientificName: "Carcharodon carcharias",
                commonName: "Great White Shark",
                averageSize: "15-20 feet (4.5-6 meters)",
                lifeSpan: "30-70 years",
                bodyShape: "Streamlined, torpedo-shaped body with a conical snout",
                habitat: "Coastal and open ocean waters worldwide.",
                diet: "Fish, seals, sea lions, and carrion."
            ),
            
            MarineAnimal(
                name: "Hammerhead Shark",
                imageName: "Hammerhead Shark",
                description: "Hammerhead Sharks are recognized by their distinctive hammer-shaped heads, which improve their vision.",
                scientificName: "Sphyrnidae",
                commonName: "Hammerhead Shark",
                averageSize: "13-20 feet (4-6 meters)",
                lifeSpan: "20-30 years",
                bodyShape: "Flattened, hammer-shaped head with an elongated body",
                habitat: "Coastal waters and continental shelves.",
                diet: "Fish, squid, stingrays, and crustaceans."
            ),
            
            MarineAnimal(
                name: "Tiger Shark",
                imageName: "Tiger Shark",
                description: "Tiger Sharks are large, aggressive sharks known for their distinctive stripes and varied diet.",
                scientificName: "Galeocerdo cuvier",
                commonName: "Tiger Shark",
                averageSize: "10-14 feet (3-4 meters)",
                lifeSpan: "20-50 years",
                bodyShape: "Robust body with a blunt snout and stripes",
                habitat: "Tropical and temperate coastal waters.",
                diet: "Fish, turtles, birds, and marine mammals."
            ),
            
            MarineAnimal(
                name: "Whale Shark",
                imageName: "Whale Shark",
                description: "The Whale Shark is the largest fish in the world, known for its gentle nature and filter-feeding habits.",
                scientificName: "Rhincodon typus",
                commonName: "Whale Shark",
                averageSize: "30-40 feet (9-12 meters)",
                lifeSpan: "70-100 years",
                bodyShape: "Massive, fusiform body with a broad, flat head",
                habitat: "Warm tropical ocean waters worldwide.",
                diet: "Plankton, small fish, and krill."
            ),
            
            MarineAnimal(
                name: "Bull Shark",
                imageName: "Bull Shark",
                description: "Bull Sharks are aggressive and can survive in both freshwater and saltwater environments.",
                scientificName: "Carcharhinus leucas",
                commonName: "Bull Shark",
                averageSize: "7-11 feet (2-3.5 meters)",
                lifeSpan: "12-16 years",
                bodyShape: "Stocky body with a broad, flat snout",
                habitat: "Coastal waters, rivers, and freshwater lakes.",
                diet: "Fish, dolphins, and other sharks."
            ),
            
            MarineAnimal(
                name: "Mako Shark",
                imageName: "Mako Shark",
                description: "Mako Sharks are the fastest sharks, reaching speeds up to 45 mph.",
                scientificName: "Isurus",
                commonName: "Mako Shark",
                averageSize: "10-12 feet (3-3.6 meters)",
                lifeSpan: "28-35 years",
                bodyShape: "Sleek, torpedo-shaped body with a pointed snout",
                habitat: "Open ocean in tropical and temperate waters.",
                diet: "Fish, squid, and smaller sharks."
            ),
            
            MarineAnimal(
                name: "Stingray",
                imageName: "Stingray",
                description: "Stingrays are flattened fish with venomous barbs on their tails for defense.",
                scientificName: "Dasyatidae",
                commonName: "Stingray",
                averageSize: "2-6 feet (0.6-1.8 meters)",
                lifeSpan: "10-25 years",
                bodyShape: "Flat, disc-shaped body with a whip-like tail",
                habitat: "Shallow coastal waters and sandy seabeds.",
                diet: "Small fish, crustaceans, and mollusks."
            ),
            
            MarineAnimal(
                name: "Manta Ray",
                imageName: "Manta Ray",
                description: "Manta Rays are large, filter-feeding rays known for their graceful movements.",
                scientificName: "Manta birostris",
                commonName: "Manta Ray",
                averageSize: "15-23 feet (4.5-7 meters)",
                lifeSpan: "20-50 years",
                bodyShape: "Broad, diamond-shaped body with large wing-like fins",
                habitat: "Warm tropical and subtropical waters.",
                diet: "Plankton and small fish."
            ),
            
            MarineAnimal(
                name: "Electric Ray",
                imageName: "Electric Ray",
                description: "Electric Rays use electric shocks to stun prey and defend against predators.",
                scientificName: "Torpediniformes",
                commonName: "Electric Ray",
                averageSize: "1-6 feet (0.3-1.8 meters)",
                lifeSpan: "10-22 years",
                bodyShape: "Round, flattened body with small eyes",
                habitat: "Coastal and deep-sea waters worldwide.",
                diet: "Fish, squid, and crustaceans."
            ),
            
            MarineAnimal(
                name: "Sawfish",
                imageName: "Sawfish",
                description: "Sawfish have long, saw-like snouts lined with sharp teeth, used for hunting prey.",
                scientificName: "Pristidae",
                commonName: "Sawfish",
                averageSize: "10-25 feet (3-7.6 meters)",
                lifeSpan: "30-50 years",
                bodyShape: "Elongated, flattened body with a long rostrum (saw)",
                habitat: "Shallow coastal waters, estuaries, and rivers.",
                diet: "Small fish and crustaceans."
            )
    ]),

    MarineCategory(title: "Marine Mammals", animals: [
        MarineAnimal(
                name: "Bottlenose Dolphin",
                imageName: "Bottlenose Dolphin",
                description: "Bottlenose Dolphins are highly intelligent and social marine mammals known for their playful behavior.",
                scientificName: "Tursiops truncatus",
                commonName: "Bottlenose Dolphin",
                averageSize: "8-12 feet (2.5-3.8 meters)",
                lifeSpan: "40-60 years",
                bodyShape: "Streamlined body with a curved dorsal fin and a pronounced beak",
                habitat: "Warm and temperate seas worldwide.",
                diet: "Fish, squid, and crustaceans."
            ),

            MarineAnimal(
                name: "Orca",
                imageName: "Orca",
                description: "Orcas, also known as Killer Whales, are apex predators with strong social bonds and advanced hunting techniques.",
                scientificName: "Orcinus orca",
                commonName: "Orca",
                averageSize: "20-26 feet (6-8 meters)",
                lifeSpan: "50-90 years",
                bodyShape: "Robust black-and-white body with a tall dorsal fin",
                habitat: "Oceans worldwide, from the Arctic to tropical seas.",
                diet: "Fish, seals, sea birds, and other marine mammals."
            ),

            MarineAnimal(
                name: "Humpback Whale",
                imageName: "Humpback Whale",
                description: "Humpback Whales are known for their acrobatic breaches and complex songs.",
                scientificName: "Megaptera novaeangliae",
                commonName: "Humpback Whale",
                averageSize: "40-50 feet (12-16 meters)",
                lifeSpan: "45-50 years",
                bodyShape: "Large body with long pectoral fins and a knobbly head",
                habitat: "Oceans worldwide, migrating between feeding and breeding grounds.",
                diet: "Krill, small fish, and plankton."
            ),

            MarineAnimal(
                name: "Blue Whale",
                imageName: "Blue Whale",
                description: "The Blue Whale is the largest animal on Earth, reaching up to 100 feet in length.",
                scientificName: "Balaenoptera musculus",
                commonName: "Blue Whale",
                averageSize: "80-100 feet (24-30 meters)",
                lifeSpan: "70-90 years",
                bodyShape: "Massive, streamlined body with a bluish-gray coloration",
                habitat: "Deep ocean waters worldwide.",
                diet: "Krill and small marine organisms."
            ),

            MarineAnimal(
                name: "Sperm Whale",
                imageName: "Sperm Whale",
                description: "Sperm Whales are deep-diving marine mammals known for their large heads and use of echolocation.",
                scientificName: "Physeter macrocephalus",
                commonName: "Sperm Whale",
                averageSize: "50-60 feet (15-18 meters)",
                lifeSpan: "60-70 years",
                bodyShape: "Massive head with a boxy shape and wrinkled skin",
                habitat: "Deep ocean waters worldwide.",
                diet: "Squid, fish, and deep-sea creatures."
            ),

            MarineAnimal(
                name: "Narwhal",
                imageName: "Narwhal",
                description: "Narwhals are Arctic whales known for their long, spiral tusks.",
                scientificName: "Monodon monoceros",
                commonName: "Narwhal",
                averageSize: "13-20 feet (4-6 meters)",
                lifeSpan: "40-50 years",
                bodyShape: "Stocky body with a long, spiral tusk in males",
                habitat: "Arctic waters of Canada, Greenland, and Russia.",
                diet: "Fish, squid, and shrimp."
            ),

            MarineAnimal(
                name: "Walrus",
                imageName: "Walrus",
                description: "Walruses are large, tusked marine mammals that inhabit Arctic regions.",
                scientificName: "Odobenus rosmarus",
                commonName: "Walrus",
                averageSize: "7-12 feet (2-3.7 meters)",
                lifeSpan: "30-40 years",
                bodyShape: "Heavy-bodied with long tusks and whiskered snout",
                habitat: "Arctic seas and ice-covered waters.",
                diet: "Clams, mollusks, and small fish."
            ),

            MarineAnimal(
                name: "Harbor Seal",
                imageName: "Harbor Seal",
                description: "Harbor Seals are agile swimmers found along coastlines and estuaries.",
                scientificName: "Phoca vitulina",
                commonName: "Harbor Seal",
                averageSize: "5-6 feet (1.5-1.8 meters)",
                lifeSpan: "20-30 years",
                bodyShape: "Plump body with short limbs and spotted fur",
                habitat: "Coastal waters of the Northern Hemisphere.",
                diet: "Fish, squid, and crustaceans."
            ),

            MarineAnimal(
                name: "Manatee",
                imageName: "Manatee",
                description: "Manatees, also known as sea cows, are gentle herbivorous marine mammals.",
                scientificName: "Trichechus",
                commonName: "Manatee",
                averageSize: "9-13 feet (2.7-4 meters)",
                lifeSpan: "40-60 years",
                bodyShape: "Large, rounded body with paddle-shaped flippers",
                habitat: "Warm coastal waters, rivers, and estuaries.",
                diet: "Seagrasses and aquatic plants."
            ),

            MarineAnimal(
                name: "Sea Otter",
                imageName: "Sea Otter",
                description: "Sea Otters are playful marine mammals known for using tools to open shellfish.",
                scientificName: "Enhydra lutris",
                commonName: "Sea Otter",
                averageSize: "3-4 feet (0.9-1.2 meters)",
                lifeSpan: "15-20 years",
                bodyShape: "Sleek, fur-covered body with webbed feet",
                habitat: "Coastal kelp forests of the North Pacific Ocean.",
                diet: "Shellfish, sea urchins, and fish."
            )
    ]),
    
    MarineCategory(title: "Reptiles", animals: [
        MarineAnimal(
            name: "Green Sea Turtle",
            imageName: "Green Sea Turtle",
            description: "Green Sea Turtles are large, herbivorous marine turtles known for their long migrations.",
            scientificName: "Chelonia mydas",
            commonName: "Green Sea Turtle",
            averageSize: "3-4 feet (0.9-1.2 meters)",
            lifeSpan: "80-100 years",
            bodyShape: "Streamlined shell with paddle-like flippers",
            habitat: "Tropical and subtropical seas worldwide.",
            diet: "Seagrasses and algae."
        ),

        MarineAnimal(
            name: "Leatherback Sea Turtle",
            imageName: "Leatherback Sea Turtle",
            description: "Leatherback Sea Turtles are the largest of all sea turtles, known for their leathery shell.",
            scientificName: "Dermochelys coriacea",
            commonName: "Leatherback Sea Turtle",
            averageSize: "6-7 feet (1.8-2.1 meters)",
            lifeSpan: "30-50 years",
            bodyShape: "Large, elongated body with a ridged, leathery shell",
            habitat: "Open ocean worldwide.",
            diet: "Jellyfish and soft-bodied marine animals."
        ),

        MarineAnimal(
            name: "Hawksbill Turtle",
            imageName: "Hawksbill Turtle",
            description: "Hawksbill Turtles are critically endangered sea turtles known for their beautiful shells.",
            scientificName: "Eretmochelys imbricata",
            commonName: "Hawksbill Turtle",
            averageSize: "2.5-3 feet (0.75-0.9 meters)",
            lifeSpan: "30-50 years",
            bodyShape: "Oval-shaped shell with a pointed beak",
            habitat: "Coral reefs, lagoons, and coastal areas.",
            diet: "Sponges, jellyfish, and small invertebrates."
        ),

        MarineAnimal(
            name: "Saltwater Crocodile",
            imageName: "Saltwater Crocodile",
            description: "Saltwater Crocodiles are the largest living reptiles, known for their powerful bite.",
            scientificName: "Crocodylus porosus",
            commonName: "Saltwater Crocodile",
            averageSize: "14-23 feet (4.3-7 meters)",
            lifeSpan: "70-100 years",
            bodyShape: "Massive body with a broad snout and rough scales",
            habitat: "Coastal waters, estuaries, and rivers in Southeast Asia and Australia.",
            diet: "Fish, birds, and mammals."
        ),

        MarineAnimal(
            name: "American Crocodile",
            imageName: "American Crocodile",
            description: "American Crocodiles are large reptiles found in brackish and freshwater habitats.",
            scientificName: "Crocodylus acutus",
            commonName: "American Crocodile",
            averageSize: "10-15 feet (3-4.5 meters)",
            lifeSpan: "50-70 years",
            bodyShape: "Long, slender snout with a ridged back",
            habitat: "Coastal areas, mangroves, and rivers in the Americas.",
            diet: "Fish, birds, and small mammals."
        ),

        MarineAnimal(
            name: "Water Monitor Lizard",
            imageName: "Water Monitor Lizard",
            description: "Water Monitor Lizards are large, semi-aquatic reptiles found in tropical regions.",
            scientificName: "Varanus salvator",
            commonName: "Water Monitor Lizard",
            averageSize: "4-7 feet (1.2-2.1 meters)",
            lifeSpan: "15-25 years",
            bodyShape: "Long, muscular body with a powerful tail",
            habitat: "Rivers, swamps, and coastal mangroves.",
            diet: "Fish, frogs, small mammals, and carrion."
        ),
        
        MarineAnimal(
            name: "Sea Snake",
            imageName: "Sea Snake",
            description: "Sea Snakes are highly venomous marine reptiles adapted for life in the ocean.",
            scientificName: "Hydrophiinae",
            commonName: "Sea Snake",
            averageSize: "3-5 feet (0.9-1.5 meters)",
            lifeSpan: "5-10 years",
            bodyShape: "Slender, elongated body with a paddle-like tail",
            habitat: "Coastal waters of the Indo-Pacific region.",
            diet: "Fish and eels."
        ),
        
        MarineAnimal(
            name: "Nile Crocodile",
            imageName: "Nile Crocodile",
            description: "Nile Crocodiles are aggressive predators known for their powerful bite.",
            scientificName: "Crocodylus niloticus",
            commonName: "Nile Crocodile",
            averageSize: "11-16 feet (3.3-4.8 meters)",
            lifeSpan: "50-70 years",
            bodyShape: "Stocky body with rough, armored skin",
            habitat: "Rivers, lakes, and estuaries in Africa.",
            diet: "Fish, birds, and large mammals."
        ),
        
        MarineAnimal(
            name: "Yellow-Bellied Sea Snake",
            imageName: "Yellow-Bellied Sea Snake",
            description: "The Yellow-Bellied Sea Snake is a highly venomous species with striking coloration.",
            scientificName: "Pelamis platura",
            commonName: "Yellow-Bellied Sea Snake",
            averageSize: "2-4 feet (0.6-1.2 meters)",
            lifeSpan: "3-5 years",
            bodyShape: "Slender body with a distinctive yellow and black pattern",
            habitat: "Tropical and subtropical ocean waters worldwide.",
            diet: "Small fish."
        ),
        
        MarineAnimal(
            name: "Gharial",
            imageName: "Gharial",
            description: "Gharials are fish-eating crocodilians with long, narrow snouts.",
            scientificName: "Gavialis gangeticus",
            commonName: "Gharial",
            averageSize: "12-15 feet (3.6-4.5 meters)",
            lifeSpan: "40-60 years",
            bodyShape: "Long, slender snout with sharp teeth",
            habitat: "Rivers in northern India and Nepal.",
            diet: "Fish."
        )
    ]),
    
    MarineCategory(title: "Amphibians", animals: [
        MarineAnimal(
            name: "Axolotl",
            imageName: "Axolotl",
            description: "Axolotls are aquatic salamanders capable of regenerating limbs and organs.",
            scientificName: "Ambystoma mexicanum",
            commonName: "Axolotl",
            averageSize: "6-18 inches (15-45 cm)",
            lifeSpan: "10-15 years",
            bodyShape: "Elongated body with feathery external gills",
            habitat: "Freshwater lakes and canals in Mexico.",
            diet: "Small fish, worms, and aquatic invertebrates."
        ),

        MarineAnimal(
            name: "African Clawed Frog",
            imageName: "African Clawed Frog",
            description: "A fully aquatic frog known for its webbed feet and claw-like toes.",
            scientificName: "Xenopus laevis",
            commonName: "African Clawed Frog",
            averageSize: "2-5 inches (5-12 cm)",
            lifeSpan: "10-15 years",
            bodyShape: "Flattened body with webbed feet and no tongue",
            habitat: "Lakes, ponds, and slow-moving water in Africa.",
            diet: "Insects, small fish, and organic debris."
        ),

        MarineAnimal(
            name: "Common Newt",
            imageName: "Common Newt",
            description: "A small amphibian that undergoes metamorphosis from aquatic larva to terrestrial adult.",
            scientificName: "Lissotriton vulgaris",
            commonName: "Common Newt",
            averageSize: "3-4 inches (7-10 cm)",
            lifeSpan: "6-15 years",
            bodyShape: "Slender body with a long tail and smooth skin",
            habitat: "Ponds, marshes, and forests in Europe.",
            diet: "Insects, worms, and small aquatic invertebrates."
        ),

        MarineAnimal(
            name: "Hellbender",
            imageName: "Hellbender",
            description: "A giant aquatic salamander that breathes through its skin.",
            scientificName: "Cryptobranchus alleganiensis",
            commonName: "Hellbender",
            averageSize: "12-29 inches (30-74 cm)",
            lifeSpan: "25-30 years",
            bodyShape: "Large, flat body with loose skin folds",
            habitat: "Clear, fast-flowing streams in the United States.",
            diet: "Crayfish, fish, and aquatic insects."
        ),

        MarineAnimal(
            name: "Green Frog",
            imageName: "Green Frog",
            description: "A common North American frog known for its deep, banjo-like call.",
            scientificName: "Lithobates clamitans",
            commonName: "Green Frog",
            averageSize: "2-4 inches (5-10 cm)",
            lifeSpan: "6-10 years",
            bodyShape: "Robust body with long legs and smooth green skin",
            habitat: "Ponds, lakes, and wetlands in North America.",
            diet: "Insects, small fish, and invertebrates."
        ),

        MarineAnimal(
            name: "American Bullfrog",
            imageName: "American Bullfrog",
            description: "The largest frog in North America, known for its powerful leap and deep call.",
            scientificName: "Lithobates catesbeianus",
            commonName: "American Bullfrog",
            averageSize: "3.5-6 inches (9-15 cm)",
            lifeSpan: "7-10 years",
            bodyShape: "Large, muscular body with long legs",
            habitat: "Lakes, ponds, and slow-moving rivers in North America.",
            diet: "Fish, insects, small mammals, and birds."
        ),

        MarineAnimal(
            name: "Fire Salamander",
            imageName: "Fire Salamander",
            description: "A striking black-and-yellow salamander known for its toxic secretions.",
            scientificName: "Salamandra salamandra",
            commonName: "Fire Salamander",
            averageSize: "6-10 inches (15-25 cm)",
            lifeSpan: "10-20 years",
            bodyShape: "Stout body with smooth, glossy skin",
            habitat: "Forests and wetlands in Europe.",
            diet: "Insects, slugs, and worms."
        ),

        MarineAnimal(
            name: "Iberian Ribbed Newt",
            imageName: "Iberian Ribbed Newt",
            description: "A unique newt that can push its ribs through its skin as a defense mechanism.",
            scientificName: "Pleurodeles waltl",
            commonName: "Iberian Ribbed Newt",
            averageSize: "6-12 inches (15-30 cm)",
            lifeSpan: "10-15 years",
            bodyShape: "Elongated body with rough skin and visible ribs",
            habitat: "Ponds and slow-moving waters in the Iberian Peninsula.",
            diet: "Insects, crustaceans, and small fish."
        ),

        MarineAnimal(
            name: "Eastern Tiger Salamander",
            imageName: "Eastern Tiger Salamander",
            description: "A large terrestrial salamander with distinctive tiger-like markings.",
            scientificName: "Ambystoma tigrinum",
            commonName: "Eastern Tiger Salamander",
            averageSize: "6-13 inches (15-33 cm)",
            lifeSpan: "10-25 years",
            bodyShape: "Stocky body with thick legs and a broad head",
            habitat: "Grasslands, woodlands, and wetlands in North America.",
            diet: "Insects, worms, and small amphibians."
        ),

        MarineAnimal(
            name: "Olm",
            imageName: "Olm",
            description: "A blind cave-dwelling salamander that relies on smell and electroreception.",
            scientificName: "Proteus anguinus",
            commonName: "Olm",
            averageSize: "8-12 inches (20-30 cm)",
            lifeSpan: "50-100 years",
            bodyShape: "Elongated, pale body with external gills",
            habitat: "Subterranean caves and freshwater springs in Europe.",
            diet: "Small crustaceans and worms."
        )
    ]),
    
    MarineCategory(title: "Mollusks", animals: [
        MarineAnimal(
            name: "Giant Squid",
            imageName: "Giant Squid",
            description: "One of the largest invertebrates on Earth, known for its elusive deep-sea nature.",
            scientificName: "Architeuthis dux",
            commonName: "Giant Squid",
            averageSize: "33-43 feet (10-13 meters)",
            lifeSpan: "5 years",
            bodyShape: "Long, torpedo-shaped body with massive tentacles",
            habitat: "Deep ocean waters worldwide.",
            diet: "Fish and other squid."
        ),

        MarineAnimal(
            name: "Blue-Ringed Octopus",
            imageName: "Blue-Ringed Octopus",
            description: "A small but highly venomous octopus with striking blue rings.",
            scientificName: "Hapalochlaena",
            commonName: "Blue-Ringed Octopus",
            averageSize: "5-8 inches (12-20 cm)",
            lifeSpan: "2-3 years",
            bodyShape: "Small, compact body with vivid blue rings",
            habitat: "Shallow coral reefs and tide pools in the Pacific and Indian Oceans.",
            diet: "Crustaceans and small fish."
        ),

        MarineAnimal(
            name: "Common Octopus",
            imageName: "Common Octopus",
            description: "A highly intelligent cephalopod known for its problem-solving abilities.",
            scientificName: "Octopus vulgaris",
            commonName: "Common Octopus",
            averageSize: "12-36 inches (30-91 cm)",
            lifeSpan: "1-2 years",
            bodyShape: "Soft-bodied with eight flexible arms",
            habitat: "Coastal waters and coral reefs worldwide.",
            diet: "Crabs, fish, and mollusks."
        ),

        MarineAnimal(
            name: "Chambered Nautilus",
            imageName: "Chambered Nautilus",
            description: "A deep-sea cephalopod with a beautifully spiraled shell.",
            scientificName: "Nautilus pompilius",
            commonName: "Chambered Nautilus",
            averageSize: "8-10 inches (20-25 cm)",
            lifeSpan: "15-20 years",
            bodyShape: "Hard spiral shell with numerous tentacles",
            habitat: "Deep reefs in the Indo-Pacific.",
            diet: "Crustaceans and small fish."
        ),

        MarineAnimal(
            name: "Cuttlefish",
            imageName: "Cuttlefish",
            description: "A cephalopod known for its ability to change color and texture instantly.",
            scientificName: "Sepia officinalis",
            commonName: "Cuttlefish",
            averageSize: "6-20 inches (15-50 cm)",
            lifeSpan: "1-2 years",
            bodyShape: "Oval-shaped body with tentacles and a cuttlebone",
            habitat: "Shallow coastal waters worldwide.",
            diet: "Shrimp, fish, and crustaceans."
        ),

        MarineAnimal(
            name: "Giant Clam",
            imageName: "Giant Clam",
            description: "One of the largest living bivalves, known for its symbiotic relationship with algae.",
            scientificName: "Tridacna gigas",
            commonName: "Giant Clam",
            averageSize: "Up to 4 feet (1.2 meters)",
            lifeSpan: "100 years or more",
            bodyShape: "Large, thick shell with wavy edges",
            habitat: "Shallow coral reefs in the Indo-Pacific.",
            diet: "Photosynthetic algae and plankton."
        ),

        MarineAnimal(
            name: "Oyster",
            imageName: "Oyster",
            description: "A filter-feeding bivalve that plays a crucial role in marine ecosystems.",
            scientificName: "Ostrea edulis",
            commonName: "Oyster",
            averageSize: "2-6 inches (5-15 cm)",
            lifeSpan: "5-20 years",
            bodyShape: "Rough, irregular shell",
            habitat: "Coastal waters and estuaries worldwide.",
            diet: "Plankton and organic particles."
        ),

        MarineAnimal(
            name: "Scallop",
            imageName: "Scallop",
            description: "A bivalve mollusk that can swim by clapping its shells together.",
            scientificName: "Pecten jacobaeus",
            commonName: "Scallop",
            averageSize: "3-6 inches (7-15 cm)",
            lifeSpan: "10-20 years",
            bodyShape: "Round, symmetrical shell with ridges",
            habitat: "Sandy seabeds and coastal waters worldwide.",
            diet: "Plankton and small organic matter."
        ),

        MarineAnimal(
            name: "Cone Snail",
            imageName: "Cone Snail",
            description: "A predatory sea snail with a venomous harpoon-like tooth.",
            scientificName: "Conus",
            commonName: "Cone Snail",
            averageSize: "2-8 inches (5-20 cm)",
            lifeSpan: "3-10 years",
            bodyShape: "Conical, elongated shell with vibrant patterns",
            habitat: "Tropical coral reefs and sandy seabeds.",
            diet: "Fish, worms, and other mollusks."
        ),

        MarineAnimal(
            name: "Nudibranch",
            imageName: "Nudibranch",
            description: "A colorful sea slug known for its striking patterns and lack of a shell.",
            scientificName: "Nudibranchia",
            commonName: "Nudibranch",
            averageSize: "0.4-12 inches (1-30 cm)",
            lifeSpan: "1 year",
            bodyShape: "Soft-bodied with feathery gills and vivid colors",
            habitat: "Coral reefs and ocean floors worldwide.",
            diet: "Sponges, corals, and hydroids."
        )
    ]),
    
    MarineCategory(title: "Crustaceans", animals: [
        MarineAnimal(
            name: "Red King Crab",
            imageName: "Red King Crab",
            description: "One of the largest and most prized crabs, known for its delicious meat.",
            scientificName: "Paralithodes camtschaticus",
            commonName: "Red King Crab",
            averageSize: "Up to 5 feet (1.5 meters) leg span",
            lifeSpan: "20-30 years",
            bodyShape: "Large, spiny shell with long legs",
            habitat: "Cold waters of the North Pacific.",
            diet: "Fish, mollusks, and detritus."
        ),

        MarineAnimal(
            name: "Japanese Spider Crab",
            imageName: "Japanese Spider Crab",
            description: "The largest arthropod in the world, known for its incredibly long legs.",
            scientificName: "Macrocheira kaempferi",
            commonName: "Japanese Spider Crab",
            averageSize: "Up to 12 feet (3.7 meters) leg span",
            lifeSpan: "50-100 years",
            bodyShape: "Small body with extremely long legs",
            habitat: "Deep waters off the coast of Japan.",
            diet: "Dead animals, shellfish, and plant material."
        ),

        MarineAnimal(
            name: "Blue Crab",
            imageName: "Blue Crab",
            description: "A highly aggressive swimming crab with bright blue claws.",
            scientificName: "Callinectes sapidus",
            commonName: "Blue Crab",
            averageSize: "5-7 inches (13-18 cm) shell width",
            lifeSpan: "3-4 years",
            bodyShape: "Oval-shaped shell with long, paddle-like rear legs",
            habitat: "Estuaries and coastal waters of the western Atlantic.",
            diet: "Fish, mollusks, and detritus."
        ),

        MarineAnimal(
            name: "Coconut Crab",
            imageName: "Coconut Crab",
            description: "The largest terrestrial arthropod, famous for its ability to crack coconuts.",
            scientificName: "Birgus latro",
            commonName: "Coconut Crab",
            averageSize: "Up to 3 feet (1 meter) leg span",
            lifeSpan: "Up to 60 years",
            bodyShape: "Large, robust body with powerful pincers",
            habitat: "Tropical islands and coastal regions.",
            diet: "Coconuts, fruits, and small animals."
        ),

        MarineAnimal(
            name: "Lobster",
            imageName: "Lobster",
            description: "A large crustacean with powerful claws and a long body.",
            scientificName: "Homarus americanus",
            commonName: "Lobster",
            averageSize: "Up to 3 feet (91 cm)",
            lifeSpan: "Up to 100 years",
            bodyShape: "Elongated body with large front claws",
            habitat: "Rocky ocean floors in the Atlantic.",
            diet: "Fish, mollusks, and algae."
        ),

        MarineAnimal(
            name: "Shrimp",
            imageName: "Shrimp",
            description: "A small, fast-swimming crustacean that is a key part of the marine food chain.",
            scientificName: "Penaeus monodon",
            commonName: "Shrimp",
            averageSize: "Up to 12 inches (30 cm)",
            lifeSpan: "1-6 years",
            bodyShape: "Slim, elongated body with long antennae",
            habitat: "Oceans, estuaries, and freshwater bodies worldwide.",
            diet: "Plankton, detritus, and small invertebrates."
        ),

        MarineAnimal(
            name: "Mantis Shrimp",
            imageName: "MantisShrimp",
            description: "A highly aggressive predator known for its powerful punching limbs.",
            scientificName: "Stomatopoda",
            commonName: "Mantis Shrimp",
            averageSize: "4-12 inches (10-30 cm)",
            lifeSpan: "6-20 years",
            bodyShape: "Colorful, segmented body with large front claws",
            habitat: "Shallow, tropical waters worldwide.",
            diet: "Crustaceans, fish, and mollusks."
        ),

        MarineAnimal(
            name: "Barnacle",
            imageName: "Barnacle",
            description: "A stationary crustacean that attaches itself to rocks, ships, and marine animals.",
            scientificName: "Cirripedia",
            commonName: "Barnacle",
            averageSize: "0.2-2 inches (0.5-5 cm)",
            lifeSpan: "5-10 years",
            bodyShape: "Hard, calcareous shell with feathery appendages",
            habitat: "Intertidal zones and marine surfaces worldwide.",
            diet: "Plankton and small particles."
        ),

        MarineAnimal(
            name: "Hermit Crab",
            imageName: "Hermit Crab",
            description: "A crab that lives inside discarded mollusk shells for protection.",
            scientificName: "Paguroidea",
            commonName: "Hermit Crab",
            averageSize: "Up to 6 inches (15 cm)",
            lifeSpan: "10-30 years",
            bodyShape: "Soft, coiled abdomen protected by a borrowed shell",
            habitat: "Sandy beaches and shallow waters worldwide.",
            diet: "Algae, detritus, and small invertebrates."
        ),

        MarineAnimal(
            name: "Horseshoe Crab",
            imageName: "Horseshoe Crab",
            description: "An ancient marine arthropod with blue blood used in medical research.",
            scientificName: "Limulus polyphemus",
            commonName: "Horseshoe Crab",
            averageSize: "Up to 2 feet (60 cm)",
            lifeSpan: "20-40 years",
            bodyShape: "Hard, horseshoe-shaped shell with a long tail spine",
            habitat: "Coastal waters and sandy shores.",
            diet: "Worms, mollusks, and algae."
        )
    ]),

    MarineCategory(title: "Cnidarians", animals: [
        MarineAnimal(
            name: "Box Jellyfish",
            imageName: "Box Jellyfish",
            description: "One of the most venomous marine animals, known for its transparent cube-shaped body.",
            scientificName: "Chironex fleckeri",
            commonName: "Box Jellyfish",
            averageSize: "Up to 10 feet (3 meters) tentacle length",
            lifeSpan: "Up to 1 year",
            bodyShape: "Box-like bell with long, trailing tentacles",
            habitat: "Coastal waters of the Indo-Pacific.",
            diet: "Small fish and plankton."
        ),

        MarineAnimal(
            name: "Moon Jellyfish",
            imageName: "Moon Jellyfish",
            description: "A common jellyfish with a translucent bell and four distinctive gonads.",
            scientificName: "Aurelia aurita",
            commonName: "Moon Jellyfish",
            averageSize: "10-16 inches (25-40 cm) bell diameter",
            lifeSpan: "1 year",
            bodyShape: "Round, translucent bell with short tentacles",
            habitat: "Temperate and tropical coastal waters worldwide.",
            diet: "Plankton, small fish, and larvae."
        ),

        MarineAnimal(
            name: "Portuguese Man o' War",
            imageName: "Portuguese Man o' War",
            description: "A siphonophore with venomous tentacles that can cause severe stings.",
            scientificName: "Physalia physalis",
            commonName: "Portuguese Man o' War",
            averageSize: "Up to 165 feet (50 meters) tentacle length",
            lifeSpan: "Unknown",
            bodyShape: "Gas-filled float with long, trailing tentacles",
            habitat: "Tropical and subtropical ocean waters.",
            diet: "Fish and plankton."
        ),

        MarineAnimal(
            name: "Fire Coral",
            imageName: "Fire Coral",
            description: "A coral-like cnidarian with painful stinging cells.",
            scientificName: "Millepora",
            commonName: "Fire Coral",
            averageSize: "Varies, up to several feet wide",
            lifeSpan: "Several years",
            bodyShape: "Branching or encrusting coral-like structure",
            habitat: "Tropical reefs and shallow waters.",
            diet: "Plankton and small marine organisms."
        ),

        MarineAnimal(
            name: "Sea Anemone",
            imageName: "Sea Anemone",
            description: "A colorful, flower-like marine animal that uses tentacles to capture prey.",
            scientificName: "Actiniaria",
            commonName: "Sea Anemone",
            averageSize: "Up to 3 feet (1 meter) across",
            lifeSpan: "50+ years",
            bodyShape: "Column-like body with tentacles on top",
            habitat: "Oceans worldwide, from shallow reefs to deep-sea floors.",
            diet: "Fish and plankton."
        ),

        MarineAnimal(
            name: "Brain Coral",
            imageName: "Brain Coral",
            description: "A coral species known for its grooved, brain-like appearance.",
            scientificName: "Diploria labyrinthiformis",
            commonName: "Brain Coral",
            averageSize: "Up to 6 feet (1.8 meters) wide",
            lifeSpan: "900+ years",
            bodyShape: "Massive, dome-like structure with maze-like ridges",
            habitat: "Shallow tropical coral reefs.",
            diet: "Plankton and microscopic algae."
        ),

        MarineAnimal(
            name: "Staghorn Coral",
            imageName: "Staghorn Coral",
            description: "A fast-growing coral with antler-like branches.",
            scientificName: "Acropora cervicornis",
            commonName: "Staghorn Coral",
            averageSize: "Up to 6 feet (1.8 meters) across",
            lifeSpan: "Several decades",
            bodyShape: "Branching, antler-like structure",
            habitat: "Shallow tropical reefs.",
            diet: "Plankton and microscopic algae."
        ),

        MarineAnimal(
            name: "Lion’s Mane Jellyfish",
            imageName: "Lion’s Mane Jellyfish",
            description: "The largest known jellyfish species with a thick mane of tentacles.",
            scientificName: "Cyanea capillata",
            commonName: "Lion’s Mane Jellyfish",
            averageSize: "Up to 120 feet (36 meters) tentacle length",
            lifeSpan: "1 year",
            bodyShape: "Large bell with dense, flowing tentacles",
            habitat: "Cold northern ocean waters.",
            diet: "Fish, crustaceans, and plankton."
        ),

        MarineAnimal(
            name: "Upside-Down Jellyfish",
            imageName: "Upside-Down Jellyfish",
            description: "A jellyfish that rests on the ocean floor with its tentacles facing upward.",
            scientificName: "Cassiopea",
            commonName: "Upside-Down Jellyfish",
            averageSize: "Up to 12 inches (30 cm) bell diameter",
            lifeSpan: "Up to 1 year",
            bodyShape: "Flat bell with upward-facing tentacles",
            habitat: "Shallow tropical waters and mangroves.",
            diet: "Plankton and small marine organisms."
        ),

        MarineAnimal(
            name: "Sun Coral",
            imageName: "Sun Coral",
            description: "A bright orange or yellow coral that thrives in deep waters without sunlight.",
            scientificName: "Tubastraea",
            commonName: "Sun Coral",
            averageSize: "Small colonies up to 1 foot (30 cm) across",
            lifeSpan: "Several decades",
            bodyShape: "Rounded, polyp-covered structure",
            habitat: "Deep-sea and shaded coral reefs.",
            diet: "Plankton and small marine organisms."
        )
    ]),
    
    MarineCategory(title: "Echinoderms", animals: [
        MarineAnimal(
            name: "Crown-of-Thorns Starfish",
            imageName: "Crown-of-Thorns Starfish",
            description: "A large, venomous starfish covered in sharp spines, known for feeding on coral reefs.",
            scientificName: "Acanthaster planci",
            commonName: "Crown-of-Thorns Starfish",
            averageSize: "Up to 25 inches (63 cm) in diameter",
            lifeSpan: "5-7 years",
            bodyShape: "Multi-armed star shape covered in venomous spines",
            habitat: "Indo-Pacific coral reefs.",
            diet: "Coral polyps."
        ),

        MarineAnimal(
            name: "Common Starfish",
            imageName: "CommonStarfish",
            description: "A widely recognized starfish species with five arms and a tough exterior.",
            scientificName: "Asterias rubens",
            commonName: "Common Starfish",
            averageSize: "Up to 12 inches (30 cm) in diameter",
            lifeSpan: "Up to 10 years",
            bodyShape: "Five-armed, radial symmetry",
            habitat: "Atlantic Ocean, from shallow waters to deep sea.",
            diet: "Mollusks and small marine animals."
        ),

        MarineAnimal(
            name: "Chocolate Chip Starfish",
            imageName: "Chocolate Chip Starfish",
            description: "A starfish with dark, cone-like spikes on its body, resembling chocolate chips.",
            scientificName: "Protoreaster nodosus",
            commonName: "Chocolate Chip Starfish",
            averageSize: "Up to 16 inches (40 cm) in diameter",
            lifeSpan: "Up to 10 years",
            bodyShape: "Five-armed with dark, pointed tubercles",
            habitat: "Indo-Pacific shallow waters and coral reefs.",
            diet: "Algae and detritus."
        ),

        MarineAnimal(
            name: "Sunflower Starfish",
            imageName: "Sunflower Starfish",
            description: "A large starfish with up to 24 arms, known for its rapid movement.",
            scientificName: "Pycnopodia helianthoides",
            commonName: "Sunflower Starfish",
            averageSize: "Up to 40 inches (1 meter) in diameter",
            lifeSpan: "Up to 10 years",
            bodyShape: "Many-armed, disc-like structure",
            habitat: "Northeastern Pacific Ocean.",
            diet: "Sea urchins, mollusks, and small invertebrates."
        ),

        MarineAnimal(
            name: "Brittle Star",
            imageName: "Brittle Star",
            description: "A starfish relative with long, flexible arms for quick movement.",
            scientificName: "Ophiuroidea",
            commonName: "Brittle Star",
            averageSize: "Up to 24 inches (60 cm) arm span",
            lifeSpan: "Up to 5 years",
            bodyShape: "Thin, flexible arms radiating from a central disc",
            habitat: "Oceans worldwide, from shallow waters to deep sea.",
            diet: "Plankton and organic matter."
        ),

        MarineAnimal(
            name: "Green Sea Urchin",
            imageName: "Green Sea Urchin",
            description: "A spiny echinoderm with a bright green body, common in cold waters.",
            scientificName: "Strongylocentrotus droebachiensis",
            commonName: "Green Sea Urchin",
            averageSize: "Up to 4 inches (10 cm) in diameter",
            lifeSpan: "Up to 30 years",
            bodyShape: "Spherical with long, movable spines",
            habitat: "North Atlantic and Arctic waters.",
            diet: "Algae and kelp."
        ),

        MarineAnimal(
            name: "Red Sea Urchin",
            imageName: "Red Sea Urchin",
            description: "A long-lived echinoderm with a bright red body, found in Pacific waters.",
            scientificName: "Mesocentrotus franciscanus",
            commonName: "Red Sea Urchin",
            averageSize: "Up to 7 inches (18 cm) in diameter",
            lifeSpan: "Up to 200 years",
            bodyShape: "Round with long, red spines",
            habitat: "Pacific Ocean, along the North American coast.",
            diet: "Algae and kelp."
        ),

        MarineAnimal(
            name: "Sand Dollar",
            imageName: "Sand Dollar",
            description: "A flat, burrowing echinoderm with a distinctive star-shaped pattern on its body.",
            scientificName: "Clypeasteroida",
            commonName: "Sand Dollar",
            averageSize: "Up to 5 inches (12 cm) in diameter",
            lifeSpan: "Up to 10 years",
            bodyShape: "Flat, round disc with radial symmetry",
            habitat: "Shallow sandy seabeds worldwide.",
            diet: "Plankton and organic particles."
        ),

        MarineAnimal(
            name: "Black Sea Cucumber",
            imageName: "Black Sea Cucumber",
            description: "A cylindrical echinoderm known for its ability to expel its internal organs as a defense mechanism.",
            scientificName: "Holothuria atra",
            commonName: "Black Sea Cucumber",
            averageSize: "Up to 24 inches (60 cm) long",
            lifeSpan: "Up to 10 years",
            bodyShape: "Soft, elongated body with leathery skin",
            habitat: "Indo-Pacific coral reefs and sandy bottoms.",
            diet: "Detritus and plankton."
        ),

        MarineAnimal(
            name: "Tiger Tail Sea Cucumber",
            imageName: "Tiger Tail Sea Cucumber",
            description: "A large sea cucumber with a striped, elongated body.",
            scientificName: "Holothuria thomasi",
            commonName: "Tiger Tail Sea Cucumber",
            averageSize: "Up to 6 feet (1.8 meters) long",
            lifeSpan: "Up to 15 years",
            bodyShape: "Long, cylindrical body with rough texture",
            habitat: "Tropical Indo-Pacific waters.",
            diet: "Detritus and organic matter."
        )
    ]),
    
    MarineCategory(title: "Plankton", animals: [
        MarineAnimal(
            name: "Krill",
            imageName: "Krill",
            description: "Small, shrimp-like crustaceans that form the base of the oceanic food chain.",
            scientificName: "Euphausia superba",
            commonName: "Krill",
            averageSize: "Up to 2.4 inches (6 cm)",
            lifeSpan: "Up to 10 years",
            bodyShape: "Small, elongated, translucent body",
            habitat: "Cold oceanic waters, especially the Southern Ocean.",
            diet: "Phytoplankton and algae."
        ),

        MarineAnimal(
            name: "Copepods",
            imageName: "Copepods",
            description: "Tiny, abundant crustaceans that serve as a major food source for marine life.",
            scientificName: "Calanus finmarchicus",
            commonName: "Copepods",
            averageSize: "0.02 - 0.08 inches (0.5 - 2 mm)",
            lifeSpan: "Up to 1 year",
            bodyShape: "Small, oval-shaped with long antennae",
            habitat: "Marine and freshwater ecosystems worldwide.",
            diet: "Phytoplankton and bacteria."
        ),

        MarineAnimal(
            name: "Diatoms",
            imageName: "Diatoms",
            description: "Single-celled algae with intricate silica cell walls, essential for oxygen production.",
            scientificName: "Bacillariophyceae",
            commonName: "Diatoms",
            averageSize: "2 - 200 micrometers",
            lifeSpan: "Varies by species",
            bodyShape: "Varied, often symmetrical with silica-based walls",
            habitat: "Oceans, lakes, and rivers worldwide.",
            diet: "Photosynthesis-based."
        ),

        MarineAnimal(
            name: "Dinoflagellates",
            imageName: "Dinoflagellates",
            description: "Single-celled plankton known for bioluminescence and harmful algal blooms.",
            scientificName: "Ceratium",
            commonName: "Dinoflagellates",
            averageSize: "10 - 100 micrometers",
            lifeSpan: "Varies by species",
            bodyShape: "Flagellated with armored or unarmored body",
            habitat: "Marine and freshwater environments.",
            diet: "Photosynthesis and consuming other plankton."
        ),

        MarineAnimal(
            name: "Radiolarians",
            imageName: "Radiolarians",
            description: "Microscopic marine protozoa with intricate silica skeletons.",
            scientificName: "Radiolaria",
            commonName: "Radiolarians",
            averageSize: "50 - 300 micrometers",
            lifeSpan: "Varies by species",
            bodyShape: "Spherical with complex, spiny silica shells",
            habitat: "Open ocean waters worldwide.",
            diet: "Bacteria and smaller plankton."
        ),

        MarineAnimal(
            name: "Water Flea",
            imageName: "Water Flea",
            description: "Small crustaceans that play a crucial role in freshwater ecosystems.",
            scientificName: "Daphnia",
            commonName: "Water Flea",
            averageSize: "0.02 - 0.2 inches (0.5 - 5 mm)",
            lifeSpan: "Up to 1 year",
            bodyShape: "Transparent, oval-shaped with large antennae",
            habitat: "Freshwater lakes, ponds, and rivers.",
            diet: "Algae and organic matter."
        ),

        MarineAnimal(
            name: "Cyanobacteria",
            imageName: "Cyanobacteria",
            description: "Photosynthetic bacteria responsible for much of Earth’s oxygen production.",
            scientificName: "Prochlorococcus",
            commonName: "Cyanobacteria",
            averageSize: "0.6 - 0.8 micrometers",
            lifeSpan: "Varies",
            bodyShape: "Small, spherical, or filamentous",
            habitat: "Oceans and freshwater bodies worldwide.",
            diet: "Photosynthesis-based."
        ),

        MarineAnimal(
            name: "Jellyfish Larvae",
            imageName: "Jellyfish Larvae",
            description: "Early life stage of jellyfish, also called scyphistomae, before developing into medusa form.",
            scientificName: "Scyphistomae",
            commonName: "Jellyfish Larvae",
            averageSize: "Few millimeters to centimeters",
            lifeSpan: "Few weeks before metamorphosis",
            bodyShape: "Small, polyp-like structure with tentacles",
            habitat: "Coastal waters and open ocean.",
            diet: "Tiny plankton and organic particles."
        ),

        MarineAnimal(
            name: "Fish Larvae",
            imageName: "Fish Larvae",
            description: "Newly hatched fish in the early developmental stage before becoming juveniles.",
            scientificName: "Ichthyoplankton",
            commonName: "Fish Larvae",
            averageSize: "Varies by species",
            lifeSpan: "Days to weeks before transformation",
            bodyShape: "Transparent, elongated, and fragile",
            habitat: "Pelagic zones of oceans and freshwater bodies.",
            diet: "Microplankton and organic matter."
        ),

        MarineAnimal(
            name: "Rotifers",
            imageName: "Rotifers",
            description: "Microscopic aquatic organisms with ciliated structures used for feeding and movement.",
            scientificName: "Rotifera",
            commonName: "Rotifers",
            averageSize: "50 - 500 micrometers",
            lifeSpan: "Few days to weeks",
            bodyShape: "Small, cylindrical with rotating cilia",
            habitat: "Freshwater and marine environments.",
            diet: "Bacteria and microalgae."
        )
    ])


]
