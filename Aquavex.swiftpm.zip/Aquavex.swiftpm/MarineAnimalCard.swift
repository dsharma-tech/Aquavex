//
//  MarineAnimalCard.swift
//  AquaWorld
//
//  Created by Disha Sharma on 15/02/25.
//

import SwiftUI

struct MarineAnimalCard: View {
    let animal: MarineAnimal

    var body: some View {
        VStack {
            Image(animal.imageName)
                .resizable()
                .scaledToFill()
                .frame(width: 250, height: 150)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .shadow(radius: 4)

            Text(animal.name)
                .font(.title3)
                .bold()
                .padding(.top, 4)
        }
        .frame(width: 250)
    }
}


// MARK: - Preview
struct MarineAnimalCard_Previews: PreviewProvider {
    static var previews: some View {
        MarineAnimalCard(animal: MarineAnimal(
            name: "Clownfish",
            imageName: "Amphiprioninae",
            description: "Clownfish",
            scientificName: "clownfish",
            commonName: "Clownfish are small, brightly colored fish that form symbiotic relationships with sea anemones.",
            averageSize: "Tropical coral reefs, mainly in the Indo-Pacific region.",
            lifeSpan: "Plankton, algae, and small crustaceans.",
            bodyShape: "10-18 cm",
            habitat: "6-10 years",
            diet: "Oval-shaped body with a rounded tail fin"
        ))
    }
}

