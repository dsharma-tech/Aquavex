import SwiftUI

@main
struct AquaWorldApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreen()
        }
    }
}
