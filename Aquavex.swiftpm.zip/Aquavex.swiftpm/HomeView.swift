import SwiftUI

struct HomeView: View {
    @State private var unlockedAnimals: [MarineAnimal] = []

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    PersonalityQuizSection(unlockedAnimals: $unlockedAnimals)
                    
                    ForEach(marineCategories, id: \.title) { category in
                        CategorySection(category: category, unlockedAnimals: $unlockedAnimals)
                    }
                }
                .padding(.top, 2)
            }
            .navigationTitle("Aquavex")
            .navigationBarItems(trailing:
                    NavigationLink(destination: AquariumView(unlockedAnimals: $unlockedAnimals)) {
                        Image(systemName: "fish.circle")
                    .font(.title)
                            .foregroundColor(.blue)
                    }
                )
            .onAppear {
                }
        }
    }
}

struct PersonalityQuizSection: View {
    @Binding var unlockedAnimals: [MarineAnimal]

    var body: some View {
        NavigationLink(destination: PersonalityQuizView(unlockedAnimals: $unlockedAnimals)) {
            HStack(spacing: 12) {
                Image(systemName: "questionmark.circle.fill")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.white)
                
                Text("Which Sea Creature Are You?")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.title2)
                    .foregroundColor(.white.opacity(0.8))
            }
            .padding()
            .frame(maxWidth: .infinity, minHeight: 60)
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue, Color.cyan]),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .cornerRadius(15)
            .shadow(color: Color.blue.opacity(0.4), radius: 5, x: 0, y: 3)
        }
        .padding(.horizontal, 16)
    }
}

struct CategorySection: View {
    let category: MarineCategory
    @Binding var unlockedAnimals: [MarineAnimal]

    var body: some View {
        VStack(alignment: .leading) {
            Text(category.title)
                .font(.title2)
                .bold()
                .padding(.leading, 16)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 25) {
                    ForEach(category.animals) { animal in
                        NavigationLink(destination: DetailView(animal: animal, unlockedAnimals: $unlockedAnimals)) {
                            MarineAnimalCard(animal: animal)
                        }
                        
                    }
                }
                .padding(.horizontal, 16)
            }
        }
    }
}

// MARK: - "My Aquarium" Section
struct AquariumView: View {
    @Binding var unlockedAnimals: [MarineAnimal]
    @State private var floatingOffsets: [CGSize] = []

    var body: some View {
        ZStack {
            VStack {
                Text("🐠 My Aquarium")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .shadow(radius: 5)
                    .padding(.top, 50)
                
                Spacer()
            }
            .zIndex(1)
            
            Image("aquarium_background")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
                .overlay(Color.blue.opacity(0.2))
                .zIndex(0)
            
            ForEach(Array(unlockedAnimals.enumerated()), id: \.offset) { index, animal in
                FloatingFishView(imageName: animal.imageName)
                    .position(randomPosition())
                    .offset(floatingOffsets[safe: index] ?? .zero)
                    .onAppear {
                        animateFish(index: index)
                    }
            }
        }
        .onAppear {
            setupOffsets()
        }
    }

    private func setupOffsets() {
        floatingOffsets = Array(repeating: .zero, count: unlockedAnimals.count)
    }

    private func randomPosition() -> CGPoint {
        CGPoint(x: CGFloat.random(in: 50...UIScreen.main.bounds.width - 50),
                y: CGFloat.random(in: 150...UIScreen.main.bounds.height - 200))
    }


    private func animateFish(index: Int) {
        withAnimation(Animation.easeInOut(duration: Double.random(in: 4...7)).repeatForever(autoreverses: true)) {
            if index < floatingOffsets.count {
                floatingOffsets[index] = CGSize(width: CGFloat.random(in: -20...20), height: CGFloat.random(in: -30...30))
            }
        }
    }
}

extension Array {
    subscript(safe index: Int) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}


struct FloatingFishView: View {
    let imageName: String
    @State private var wiggleOffset: CGSize = .zero

    var body: some View {
        Image(imageName)
            .resizable()
            .scaledToFit()
            .frame(width: 80, height: 80)
            .clipShape(Circle())
            .shadow(radius: 5)
            .onAppear {
                animateWiggle()
            }
            .offset(wiggleOffset)
    }

    private func animateWiggle() {
        withAnimation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true)) {
            wiggleOffset = CGSize(width: CGFloat.random(in: -10...10), height: CGFloat.random(in: -5...5))
        }
    }
}

// MARK: - Preview
#Preview {
    HomeView()
}
