//
//  PersonalityQuizView.swift
//  AquaWorld
//
//  Created by Disha Sharma on 15/02/25.
//

import SwiftUI

struct PersonalityQuizView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var currentQuestionIndex = 0
    @State private var selectedAnswers: [String] = []
    @Binding var unlockedAnimals: [MarineAnimal]
    @State private var showResult = false
    @State private var resultAnimal: MarineAnimal?
    
    
    let questions: [(question: String, options: [String])] = [
        ("How do you like to spend your day?",
                ["🏊 Floating and drifting along!",
                 "🌞 Soaking up the sun!",
                 "💡 Lighting up the night!",
                 "🏆 Helping my friends stay strong!"]),

            ("What’s your special superpower?",
                ["🌊 I go with the flow!",
                 "🔬 I clean and filter water!",
                 "✨ I glow in the dark!",
                 "🌱 I help others grow!"]),

            ("If you were part of a team, what would you do?",
                ["🍽️ Be the snack everyone needs!",
                 "💡 Shine bright to guide my team!",
                 "🛡️ Protect my friends with my shell!",
                 "🌎 Keep everything balanced and working smoothly!"]),

            ("What’s your favorite place in the ocean?",
                ["❄️ The icy, deep waters!",
                 "🏝️ The warm, sunny shallows!",
                 "🌌 Anywhere that glows at night!",
                 "🏞️ Wherever I can help other creatures grow!"]),

            ("If you were in a race, what would you do?",
                ["🏄 Let the waves push me along!",
                 "🏋️ Use my strength to move forward!",
                 "🎆 Make a bright, glowing finish!",
                 "🤝 Help my friends cross the finish line too!"]),

            ("Which of these do you like the most?",
                ["🍉 Tiny, tasty treats!",
                 "🏠 A safe and strong home!",
                 "🎇 Sparkles and glowing things!",
                 "🌱 Making the world greener!"]),

            ("What’s your favorite school subject?",
                ["📚 Science – I love learning about nature!",
                 "🎨 Art – I like to glow and shine!",
                 "🤔 Math – I solve problems and think a lot!",
                 "🌱 Geography – I want to take care of the Earth!"])
    ]

        let resultMappings: [MarineAnimal] = [
            MarineAnimal(
                name: "Clownfish",
                imageName: "Clownfish",
                description: "Clownfish are small, brightly colored fish that form symbiotic relationships with sea anemones.",
                scientificName: "Amphiprioninae",
                commonName: "Clownfish",
                averageSize: "4-5 inches (10-12 cm)",
                lifeSpan: "6-10 years",
                bodyShape: "Oval-shaped with rounded fins",
                habitat: "Tropical coral reefs, mainly in the Indo-Pacific region.",
                diet: "Plankton, algae, and small crustaceans."
                ),
                
                MarineAnimal(
                    name: "Goldfish",
                    imageName: "Goldfish",
                    description: "Goldfish are one of the most popular freshwater aquarium fish, known for their golden coloration.",
                    scientificName: "Carassius auratus",
                    commonName: "Goldfish",
                    averageSize: "6-14 inches (15-35 cm)",
                    lifeSpan: "10-15 years",
                    bodyShape: "Rounded body with flowing fins",
                    habitat: "Freshwater lakes, ponds, and slow-moving rivers.",
                    diet: "Flakes, pellets, insects, and plant matter."
                ),

                MarineAnimal(
                    name: "Great White Shark",
                    imageName: "Great White Shark",
                    description: "The Great White Shark is one of the ocean's top predators, known for its size and powerful bite.",
                    scientificName: "Carcharodon carcharias",
                    commonName: "Great White Shark",
                    averageSize: "15-20 feet (4.5-6 meters)",
                    lifeSpan: "30-70 years",
                    bodyShape: "Streamlined, torpedo-shaped body with a conical snout",
                    habitat: "Coastal and open ocean waters worldwide.",
                    diet: "Fish, seals, sea lions, and carrion."
                ),
                
                MarineAnimal(
                    name: "Hammerhead Shark",
                    imageName: "Hammerhead Shark",
                    description: "Hammerhead Sharks are recognized by their distinctive hammer-shaped heads, which improve their vision.",
                    scientificName: "Sphyrnidae",
                    commonName: "Hammerhead Shark",
                    averageSize: "13-20 feet (4-6 meters)",
                    lifeSpan: "20-30 years",
                    bodyShape: "Flattened, hammer-shaped head with an elongated body",
                    habitat: "Coastal waters and continental shelves.",
                    diet: "Fish, squid, stingrays, and crustaceans."
                ),

                MarineAnimal(
                    name: "Bottlenose Dolphin",
                    imageName: "Bottlenose Dolphin",
                    description: "Bottlenose Dolphins are highly intelligent and social marine mammals known for their playful behavior.",
                    scientificName: "Tursiops truncatus",
                    commonName: "Bottlenose Dolphin",
                    averageSize: "8-12 feet (2.5-3.8 meters)",
                    lifeSpan: "40-60 years",
                    bodyShape: "Streamlined body with a curved dorsal fin and a pronounced beak",
                    habitat: "Warm and temperate seas worldwide.",
                    diet: "Fish, squid, and crustaceans."
                ),

                MarineAnimal(
                    name: "Orca",
                    imageName: "Orca",
                    description: "Orcas, also known as Killer Whales, are apex predators with strong social bonds and advanced hunting techniques.",
                    scientificName: "Orcinus orca",
                    commonName: "Orca",
                    averageSize: "20-26 feet (6-8 meters)",
                    lifeSpan: "50-90 years",
                    bodyShape: "Robust black-and-white body with a tall dorsal fin",
                    habitat: "Oceans worldwide, from the Arctic to tropical seas.",
                    diet: "Fish, seals, sea birds, and other marine mammals."
                ),
            
                MarineAnimal(
                    name: "Green Sea Turtle",
                    imageName: "Green Sea Turtle",
                    description: "Green Sea Turtles are large, herbivorous marine turtles known for their long migrations.",
                    scientificName: "Chelonia mydas",
                    commonName: "Green Sea Turtle",
                    averageSize: "3-4 feet (0.9-1.2 meters)",
                    lifeSpan: "80-100 years",
                    bodyShape: "Streamlined shell with paddle-like flippers",
                    habitat: "Tropical and subtropical seas worldwide.",
                    diet: "Seagrasses and algae."
                ),

                MarineAnimal(
                    name: "Leatherback Sea Turtle",
                    imageName: "Leatherback Sea Turtle",
                    description: "Leatherback Sea Turtles are the largest of all sea turtles, known for their leathery shell.",
                    scientificName: "Dermochelys coriacea",
                    commonName: "Leatherback Sea Turtle",
                    averageSize: "6-7 feet (1.8-2.1 meters)",
                    lifeSpan: "30-50 years",
                    bodyShape: "Large, elongated body with a ridged, leathery shell",
                    habitat: "Open ocean worldwide.",
                    diet: "Jellyfish and soft-bodied marine animals."
                ),

                MarineAnimal(
                    name: "Giant Squid",
                    imageName: "Giant Squid",
                    description: "One of the largest invertebrates on Earth, known for its elusive deep-sea nature.",
                    scientificName: "Architeuthis dux",
                    commonName: "Giant Squid",
                    averageSize: "33-43 feet (10-13 meters)",
                    lifeSpan: "5 years",
                    bodyShape: "Long, torpedo-shaped body with massive tentacles",
                    habitat: "Deep ocean waters worldwide.",
                    diet: "Fish and other squid."
                ),

                MarineAnimal(
                    name: "Blue-Ringed Octopus",
                    imageName: "Blue-Ringed Octopus",
                    description: "A small but highly venomous octopus with striking blue rings.",
                    scientificName: "Hapalochlaena",
                    commonName: "Blue-Ringed Octopus",
                    averageSize: "5-8 inches (12-20 cm)",
                    lifeSpan: "2-3 years",
                    bodyShape: "Small, compact body with vivid blue rings",
                    habitat: "Shallow coral reefs and tide pools in the Pacific and Indian Oceans.",
                    diet: "Crustaceans and small fish."
                ),

                MarineAnimal(
                    name: "Red King Crab",
                    imageName: "Red King Crab",
                    description: "One of the largest and most prized crabs, known for its delicious meat.",
                    scientificName: "Paralithodes camtschaticus",
                    commonName: "Red King Crab",
                    averageSize: "Up to 5 feet (1.5 meters) leg span",
                    lifeSpan: "20-30 years",
                    bodyShape: "Large, spiny shell with long legs",
                    habitat: "Cold waters of the North Pacific.",
                    diet: "Fish, mollusks, and detritus."
                ),

                MarineAnimal(
                    name: "Mantis Shrimp",
                    imageName: "MantisShrimp",
                    description: "A highly aggressive predator known for its powerful punching limbs.",
                    scientificName: "Stomatopoda",
                    commonName: "Mantis Shrimp",
                    averageSize: "4-12 inches (10-30 cm)",
                    lifeSpan: "6-20 years",
                    bodyShape: "Colorful, segmented body with large front claws",
                    habitat: "Shallow, tropical waters worldwide.",
                    diet: "Crustaceans, fish, and mollusks."
                )
    ]

    var body: some View {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue.opacity(0.1), Color.cyan.opacity(0.1)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    if showResult {
                        showResultView()
                    } else {
                        HStack(spacing: 4) {
                            ForEach(0..<questions.count, id: \.self) { index in
                                Capsule()
                                    .fill(index <= currentQuestionIndex ? Color.blue : Color.gray.opacity(0.3))
                                    .frame(height: 4)
                                    .animation(.easeInOut, value: currentQuestionIndex)
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 10)
                        
                        Text("Question \(currentQuestionIndex + 1) of \(questions.count)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                        
                        VStack(spacing: 12) {
                            Text(questions[currentQuestionIndex].question)
                                .font(.title2)
                                .fontWeight(.bold)
                                .multilineTextAlignment(.center)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.white.opacity(0.9))
                                .cornerRadius(12)
                                .shadow(color: Color.blue.opacity(0.2), radius: 5)
                        }
                        .padding(.horizontal, 16)
                        
                        VStack(spacing: 12) {
                            ForEach(questions[currentQuestionIndex].options, id: \.self) { option in
                                Button(action: {
                                    withAnimation(.easeInOut(duration: 0.5)) {
                                        answerSelected(option)
                                    }
                                }) {
                                    Text(option)
                                        .font(.headline)
                                        .multilineTextAlignment(.center)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(
                                            LinearGradient(
                                                gradient: Gradient(colors: [Color.blue, Color.cyan]),
                                                startPoint: .leading,
                                                endPoint: .trailing
                                            )
                                        )
                                        .foregroundColor(.white)
                                        .cornerRadius(12)
                                        .shadow(color: Color.blue.opacity(0.3), radius: 4)
                                }
                                .padding(.horizontal, 20)
                                .transition(.move(edge: .trailing))
                            }
                        }
                    }
                }
                .padding()
                .navigationTitle("Personality Quiz")
            }
        }
    
    private func answerSelected(_ option: String) {
        selectedAnswers.append(option)
        if currentQuestionIndex < questions.count - 1 {
            currentQuestionIndex += 1
        } else {
            determineResult()
        }
    }
    
    private func determineResult() {
        let resultIndex = selectedAnswers.reduce(0) { $0 + ($1.count % resultMappings.count) } % resultMappings.count
        resultAnimal = resultMappings[resultIndex]
        if let animal = resultAnimal {
            unlockedAnimals.append(animal)
        }
        showResult = true
    }
    
    @ViewBuilder
    private func showResultView() -> some View {
        if let animal = resultAnimal {
            VStack(spacing: 16) {
                Text("You're a")
                    .font(.title)
                    .bold()
                
                VStack {
                    Image(animal.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.blue, lineWidth: 4))
                    
                    Text(animal.name)
                        .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)
                            .font(.largeTitle)
                            .bold()
                            .foregroundColor(.blue)
                            .lineLimit(nil) // Allow unlimited lines
                            .fixedSize(horizontal: false, vertical: true)
                }
                .padding()

                Text(animal.description)
                    .font(.title3)
                    .padding()
                    .multilineTextAlignment(.center)

                Button(action: {
                                presentationMode.wrappedValue.dismiss() 
                            }) {
                                Text("Return to Home")
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.green)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                            .padding(.horizontal)
                        }
                        .padding()
                        .navigationBarBackButtonHidden(true)
        }
    }

}

// MARK: - Preview
#Preview {
    PersonalityQuizView(unlockedAnimals: .constant([]))
}
