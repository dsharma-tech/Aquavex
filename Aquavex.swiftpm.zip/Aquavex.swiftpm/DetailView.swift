import SwiftUI

struct DetailView: View {
    let animal: MarineAnimal
    @Binding var unlockedAnimals: [MarineAnimal]
    @State private var showConfetti = false
    @Environment(\.presentationMode) var presentationMode
    @State private var navigateToAquarium = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Image(animal.imageName)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity, minHeight: 250, maxHeight: 300)
                    .clipped()
                
                VStack(alignment: .leading, spacing: 12) {
                    Text(animal.name)
                        .font(.largeTitle)
                        .bold()
                    
                    Text("(\(animal.scientificName))")
                        .font(.title3)
                        .italic()
                        .foregroundColor(.gray)
                    
                    Text("About")
                        .font(.title2)
                        .bold()
                    
                    Text(animal.description)
                        .font(.body)
                        .foregroundColor(.gray)
                    
                    Divider()
                    
                    Group {
                        Text("Habitat:")
                            .font(.headline)
                        
                        Text(animal.habitat)
                            .font(.body)
                            .foregroundColor(.gray)
                        
                        Divider()
                        
                        Text("Diet:")
                            .font(.headline)
                        
                        Text(animal.diet)
                            .font(.body)
                            .foregroundColor(.gray)
                        
                        Divider()
                        
                        Text("Average Size:")
                            .font(.headline)
                        
                        Text(animal.averageSize)
                            .font(.body)
                            .foregroundColor(.gray)
                        
                        Divider()
                        
                        Text("Life Span:")
                            .font(.headline)
                        
                        Text(animal.lifeSpan)
                            .font(.body)
                            .foregroundColor(.gray)
                        
                        Divider()
                        
                        Text("Body Shape:")
                            .font(.headline)
                        
                        Text(animal.bodyShape)
                            .font(.body)
                            .foregroundColor(.gray)
                    }
                    
                    Button(action: {
                                            if !unlockedAnimals.contains(where: { $0.id == animal.id }) {
                                                withAnimation {
                                                    unlockedAnimals.append(animal)
                                                    showConfetti = true
                                                }
                                                navigateToAquarium = true
                                            }
                                        }) {
                                            HStack {
                                                Image(systemName: "plus.circle.fill")
                                                    .font(.title2)
                                                Text(unlockedAnimals.contains(where: { $0.id == animal.id }) ? "Fish Already Added" : "Add to Aquarium")
                                                    .font(.title2)
                                            }
                                            .padding()
                                            .frame(maxWidth: .infinity)
                                            .background(unlockedAnimals.contains(where: { $0.id == animal.id }) ? Color.gray : Color.blue)
                                            .foregroundColor(.white)
                                            .cornerRadius(12)
                                        }
                                        .padding(.top, 10)
                                        .disabled(unlockedAnimals.contains(where: { $0.id == animal.id })) 
                                        if showConfetti {
                                            ConfettiView()
                                                .transition(.scale)
                                                .onAppear {
                                                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                                        withAnimation {
                                                            showConfetti = false
                                                        }
                                                    }
                                                }
                                        }
                                    }
                                    .padding(.horizontal, 16)
                                }
                            }
                            .navigationTitle(animal.name)
                            .navigationBarTitleDisplayMode(.inline)
                            .background(
                                NavigationLink(destination: AquariumView(unlockedAnimals: $unlockedAnimals), isActive: $navigateToAquarium) {
                                    EmptyView()
                                }
                            )
    }
}


// MARK: - Preview
struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(animal: MarineAnimal(
            name: "Clownfish",
            imageName: "Amphiprioninae",
            description: "Clownfish",
            scientificName: "clownfish",
            commonName: "Clownfish are small, brightly colored fish that form symbiotic relationships with sea anemones.",
            averageSize: "Tropical coral reefs, mainly in the Indo-Pacific region.",
            lifeSpan: "Plankton, algae, and small crustaceans.",
            bodyShape: "10-18 cm",
            habitat: "6-10 years",
            diet: "Oval-shaped body with a rounded tail fin"
        ),
        unlockedAnimals: .constant([]))
    }
}


// MARK: - Confetti Animation 🎉
struct ConfettiView: View {
    @State private var animate = false
    
    var body: some View {
        ZStack {
            ForEach(0..<20, id: \.self) { i in
                Circle()
                    .frame(width: 10, height: 10)
                    .foregroundColor(randomColor())
                    .offset(x: animate ? CGFloat.random(in: -150...150) : 0,
                            y: animate ? CGFloat.random(in: -150...150) : 0)
                    .opacity(animate ? 0 : 1)
                    .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: false), value: animate)
            }
        }
        .onAppear {
            animate = true
        }
    }
    
    func randomColor() -> Color {
        let colors: [Color] = [.red, .blue, .yellow, .green, .orange, .pink, .purple]
        return colors.randomElement() ?? .white
    }
}
